# from ffmpeg_streaming import Formats, Bitrate, Representation, Size
# import ffmpeg_streaming


# video = ffmpeg_streaming.input('/dev/video0', capture=True)

# _480p  = Representation(Size(1280, 720), Bitrate(750 * 1024, 192 * 1024))

# hls = video.hls(Formats.h264(), hls_list_size=20, hls_time=5)
# hls.flags('delete_segments')
# hls.representations(_480p)
# hls.output('./media/hls.m3u8')

# video1 = ffmpeg_streaming.input('./media/hls.m3u8')

# stream = video.stream2file(Formats.h264())
# stream.output('./media/new-video.mp4')


import numpy as np
import cv2

cap = cv2.VideoCapture(0)

# Define the codec and create VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'XVID')
index = 0
while (True):
    
    out = cv2.VideoWriter('videos/output'+str(index)+'.avi',fourcc, 20.0, (640,480))
    counter = 0

    while(cap.isOpened()):
        ret, frame = cap.read()
        
        if(ret==True):

            # write the flipped frame
            out.write(frame)
            counter = counter + 1

            if(counter == 120 ): 
                break
        else:
            break
        if(counter == 120 ):
            break
    index = index + 1

# Release everything if job is finished
cap.release()
out.release()
cv2.destroyAllWindows()
