import argparse
import io
import re
import os
from time import sleep

from google.cloud import videointelligence_v1p3beta1 as videointelligence
from google.cloud import texttospeech
from pydub import AudioSegment
from pydub.playback import play

from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types
import pyaudio
from six.moves import queue

import threading

# Instantiates text to speech
clientTxtSpeech = texttospeech.TextToSpeechClient()
#setting voice textToSpeech
voice = texttospeech.types.VoiceSelectionParams(language_code='es-ES',ssml_gender=texttospeech.enums.SsmlVoiceGender.NEUTRAL)
#setting configuration format of the audio
audio_config = texttospeech.types.AudioConfig(audio_encoding=texttospeech.enums.AudioEncoding.MP3)


# Audio recording parameters
RATE = 16000
CHUNK = int(RATE / 10)


client = speech.SpeechClient()
config = types.RecognitionConfig(
    encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
    sample_rate_hertz=RATE,
    language_code='es-ES')
streaming_config = types.StreamingRecognitionConfig(
    config=config,
    interim_results=True)

detect_welcome = True
detecta_manos = False


chunk_size = 500 * 1024

run = True


class MicrophoneStream(object):
    """Opens a recording stream as a generator yielding the audio chunks."""
    def __init__(self, rate, chunk):
        self._rate = rate
        self._chunk = chunk

        # Create a thread-safe buffer of audio data
        self._buff = queue.Queue()
        self.closed = True

    def __enter__(self):
        self._audio_interface = pyaudio.PyAudio()
        self._audio_stream = self._audio_interface.open(
            format=pyaudio.paInt16,
            # The API currently only supports 1-channel (mono) audio
            # https://goo.gl/z757pE
            channels=1, rate=self._rate,
            input=True, frames_per_buffer=self._chunk,
            # Run the audio stream asynchronously to fill the buffer object.
            # This is necessary so that the input device's buffer doesn't
            # overflow while the calling thread makes network requests, etc.
            stream_callback=self._fill_buffer,
        )

        self.closed = False

        return self

    def __exit__(self, type, value, traceback):
        self._audio_stream.stop_stream()
        self._audio_stream.close()
        self.closed = True
        # Signal the generator to terminate so that the client's
        # streaming_recognize method will not block the process termination.
        self._buff.put(None)
        self._audio_interface.terminate()

    def _fill_buffer(self, in_data, frame_count, time_info, status_flags):
        """Continuously collect data from the audio stream, into the buffer."""
        self._buff.put(in_data)
        return None, pyaudio.paContinue

    def generator(self):
        while not self.closed:
            # Use a blocking get() to ensure there's at least one chunk of
            # data, and stop iteration if the chunk is None, indicating the
            # end of the audio stream.
            chunk = self._buff.get()
            if chunk is None:
                return
            data = [chunk]

            # Now consume whatever other data's still buffered.
            while True:
                try:
                    chunk = self._buff.get(block=False)
                    if chunk is None:
                        return
                    data.append(chunk)
                except queue.Empty:
                    break

            yield b''.join(data)





def reproduce_speech(response):
    # The response's audio_content is binary.
    with open('output.mp3', 'wb') as out:
        # Write the response to the output file.
        out.write(response.audio_content)
    sound = AudioSegment.from_mp3('output.mp3')
    play(sound)
    os.remove("output.mp3")


    
def streaming_annotate(stream_file):

    global detect_welcome
    global chunk_size
    global detecta_manos

    client = videointelligence.StreamingVideoIntelligenceServiceClient() 

    label_config = videointelligence.types.StreamingLabelDetectionConfig(stationary_camera=True)
    config = videointelligence.types.StreamingVideoConfig(feature=(videointelligence.enums.StreamingFeature.STREAMING_LABEL_DETECTION), label_detection_config=label_config)

    # config_request should be the first in the stream of requests.
    config_request = videointelligence.types.StreamingAnnotateVideoRequest(video_config=config)

   

    # Load file content.
    stream = []
    with io.open(stream_file, 'rb') as video_file:
        while True:
            data = video_file.read(chunk_size)
            if not data:
                break

            stream.append(data)

    def stream_generator():
        yield config_request
        counter = 0
        for chunk in stream:
            yield videointelligence.types.StreamingAnnotateVideoRequest(input_content=chunk)

    requests = stream_generator()

    # streaming_annotate_video returns a generator.
    # timeout argument specifies the maximum allowable time duration between
    # the time that the last packet is sent to Google video intelligence API
    # and the time that an annotation result is returned from the API.
    # timeout argument is represented in number of seconds.
    responses = client.streaming_annotate_video(requests, timeout=3600)



    # Each response corresponds to about 1 second of video.
 
    persona = ["jaw", "hair", "facial hair", "chin", "eyebrow", "mask", "nose", "mouth", "smile", "lips"]
    mano = ["hand","hands","palm","finger","fingers", "thumb"]
    check_person = 0
    check_hand = 0
    mask = False
    

    for response in responses:
        if response.error.message:
            print(response.error.message)
            break


        # Ver qué etiquetas devuelve
        for annotation in response.annotation_results.label_annotations:
            description = annotation.entity.description
            confidence = annotation.frames[0].confidence
            if detect_welcome:
                if description in persona:
                    if (description == "mask"): # TODO: revisar que esto funciona
                        mask = True
                    if (confidence > 0.50):
                        check_person+=1
            elif detecta_manos:
                if description in mano:
                    if (confidence > 0.50):
                        check_hand+=1
                    

        # Si es persona o está enseñando manos
        if(check_person >= 3):
            if(detect_welcome == True):
                if not mask:
                    interaction_speech("mask")
                else:
                    interaction_speech("bienvenida")
        if(check_hand >= 3):
            interaction_speech("manos")



    # for annotation in response.annotation_results.label_annotations:
    #     description = annotation.entity.description
    #     # Every annotation has only one frame
    #     confidence = annotation.frames[0].confidence
    #     print('\t{} (confidence: {})'.format(
    #         description.encode('utf-8').strip(), confidence))





def processing():
    global run
    #Empezar el proceso de live object labeling despues de 4 segundos de ejecutar el programa
    sleep(4)
    index = 0
    sleeping_offset = 0
    while(True):
        if (run == True):
            streaming_annotate("videos/output"+str(index)+".avi") 
        os.remove("videos/output"+str(index)+".avi") 
        #check how much avis


        if(run == False):
            dir_name = "/home/chamorro/Desktop/SpeechToText/videos"
            test = os.listdir(dir_name)

            test.sort()

            test = sorted(test)
            for item in test[:-1]:
                if item.endswith(".avi"):
                    #borrar todos menos el último, pillar el index del ultimo y actualizarlo
                    os.remove(os.path.join(dir_name, item))
            test = test[-1].split('output')
            index = test[1].split('.avi')
            index = int(index[0])

            run = True
        else:
            index = index +1


def capturing_video():
    # Llama al programa que captura video a traves de la camara
    os.system('python3 stream.py') 


def listening():
    # Cloud Speech-to-text
    with MicrophoneStream(RATE, CHUNK) as stream:
        audio_generator = stream.generator()
        requests = (types.StreamingRecognizeRequest(audio_content=content)
                    for content in audio_generator)

        responses = client.streaming_recognize(streaming_config, requests)

        # Now, put the transcription responses to use.
        interaction_listen(responses)


def interaction_listen(responses):

    num_chars_printed = 0
    for response in responses:
        if not response.results:
            continue

        # The `results` list is consecutive. For streaming, we only care about
        # the first result being considered, since once it's `is_final`, it
        # moves on to considering the next utterance.
        result = response.results[0]
        if not result.alternatives:
            continue

        # Display the transcription of the top alternative.
        transcript = result.alternatives[0].transcript

      
        transcript = ""
        if result.is_final:

            transcript = result.alternatives[0].transcript
            
            # Posibles inputs de voz
            estado = ["bien", 'genial', 'fantástico', 'perfecto'] 
            sintomas_leves = ["mal", "duele", "dolor", "cabeza", "tos", "fiebre"]
            simptomas_graves = ["respirar", "falta", "aire", "pecho", "muriendo"]

            # Accion de respuesta  
            acciones = {}
            acciones["good"] = estado
            acciones["leves"] = sintomas_leves
            acciones["graves"] = simptomas_graves
            

            option = ""
            for key, value in acciones.items():
                for word in transcript.split():
                    if word in value:
                        option = key
                        break
                            
            interaction_speech(option)


def interaction_speech(action):
    global detect_welcome
    global chunk_size
    global run
    global detecta_manos

    # Si detecta a la persona por primera vez en la ejecucion del programa
    if(detect_welcome == True):
        if(action == "bienvenida"):
            print("Bienvenida")
            speech("Bienvenido a casa, ¿Cómo te encuentras?")
        elif(action == "mask"):
            print("Bienvenida")
            speech("Bienvenido a casa, recuerda que debes llevar mascarilla al salir a la calle. ¿Cómo te encuentras?")
        detect_welcome = False
        

    if (action == "good"):
        print("Síntoma: Bueno")
        speech("Me alegro, recuerda seguir las noticias y estar al dia con las instrucciones del departamento de sanidad.")
        speech("Ahora deberías lavarte las manos. Cuando lo hayas hecho muestra las palmas de tus manos a la cámara.")
        run = False
        detecta_manos = True
        
    if(action == "leves"):
        print("Síntoma: Leve")
        speech("Parece ser que tienes síntomas leves, haz reposo y evita el contacto con otras personas.")
        speech("Ahora deberías lavarte las manos. Cuando lo hayas hecho muestra las palmas de tus manos a la cámara.")
        run = False
        detecta_manos = True
    if(action == "graves"):
        print("Síntoma: Grave")
        speech("Parece ser que tienes algun síntoma considerado grave, deberías contactar con algún centro médico para recibir atención lo antes posible.")
        speech("Ahora deberías lavarte las manos. Cuando lo hayas hecho muestra las palmas de tus manos a la cámara.")
        run = False
        detecta_manos = True
        
        
     

    # Si es un aviso rutinario para lavarse las manos
    if(action == "manos"):
        detecta_manos = False
        speech("Manos lavadas, muy bien. Dentro de una hora te avisaré otra vez.")
        timer()
        speech("Hola. Ha pasado una hora desde que te lavaste las manos. Ahora deberías lavartelas otra vez. Cuando lo hayas hecho, muestra las palmas de tus manos a la cámara.")
        run = False
        detecta_manos = True


    
def timer():
    timer = threading.Timer(10.0, None) #1 hora = 3600 segundos
    timer.start() 

def speech(text):
    # Cloud Text-to-speech
    synthesis_input = texttospeech.types.SynthesisInput(text=text)
    response = clientTxtSpeech.synthesize_speech(synthesis_input, voice, audio_config)
    reproduce_speech(response)


if __name__ == '__main__':
    
    os.system('export GOOGLE_APPLICATION_CREDENTIALS="./amazing-codex-276616-dde6f757d28f.json"')

    dir_name = "/home/chamorro/Desktop/SpeechToText/videos"
    test = os.listdir(dir_name)

    for item in test:
        if item.endswith(".avi"):
            os.remove(os.path.join(dir_name, item))

    #Inicializar los 3 procesos: video, audio, labeling
    t1 = threading.Thread(target=capturing_video)
    t2 = threading.Thread(target=processing)
    t3 = threading.Thread(target=listening)

    t1.start()
    t2.start()
    t3.start()



   